import React, { useState} from "react";

const Content = () => {
    const [showMore, setShowMore] = useState(false);

    const handleToggle = () => {
        setShowMore((prev) => !prev);
    };

    return(
        <main style={styles.Content}>
            <h2>Bem vindo ao seu relatório de histórico Escolar!</h2>
            <p>
                O site de histório escolar tem como objetivo auxiliar na medição de desemepnho semestral dos alunos referente a cada nota de determinada disciplina, e assim, medir seu nível de competência para cada matéria, bem como seu risco de aprovação e reprovação. O site mostrará quanto cada aluno cadastrado no sistema obteve de nota nas seguintes matérias: <b>Sistemas Operacionais, Front-End, Back-End e Programação Orientada a Objetos</b>. Cada disciplina terá seu respectivo professor.
            </p>
            <button onClick={handleToggle} style={styles.button}>
                {showMore ? 'Mostrar Menos' : 'Mostrar Mais'}
            </button>
        </main>
    );
};

const styles = {
    content: {
        padding: '20px',
        textAling: 'center',
    },
    button: {
        backgroundColor: '#4CAF50',
        color: 'white',
        border: 'none',
        padding: '10px 20px',
        cursor: 'pointer',
        marginTop: '10px',
    },
};

export default Content;