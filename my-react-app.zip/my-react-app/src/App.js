import React, { useState } from 'react';
import './App.css';
import Header from './Components/Header';
import Footer from './Components/Footer';
import Content from './Pages/Content';
import './index';
import FormProfessor from './Components/FormProfessor';
import FormEstudante from './Components/FormEstudante';
import TabelaDados from './Components/TabelaDados';

 

function App() {
  const [professores, setProfessores ] = useState([]);
  const [estudantes, setEstudantes ] = useState([]);

  const addProfessor = (professor) => setProfessores([...professores, professor])
  const addEstudante = (estudante) => setEstudantes([...estudantes, estudante])
  
  const updateEntradaGrade = (estudanteName, subject, grade) => {
    setEstudantes((prevEstudantes) =>
      prevEstudantes.map((estudante) =>
        estudante.name === estudanteName
          ? {
              ...estudante,
              grades: { ...estudante.grades, [subject]: grade },
            }
          : estudante
      )
    );
  };

  return (
    <div className="App">
      <h1>Histórico Escolar</h1>
      <FormProfessor addProfessor={addProfessor}></FormProfessor>
      <FormEstudante addEstudante={addEstudante}></FormEstudante>
      <TabelaDados title="Professores" data={professores}></TabelaDados>
      <TabelaDados title="Alunos" data={estudantes}></TabelaDados>
      <Header/>
      <Content />
      <Footer />
    </div>
  );
}

export default App;
