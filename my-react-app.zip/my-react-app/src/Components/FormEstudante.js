import React, { useState } from "react";

const FormEstudante = ({ addEstudante }) => {
    const [name, setName] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        addEstudante({ name, grades: {} }); // notas vazias
        setName('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Cadastrar Aluno</h2>
            <input>
                type="text"
                placeholder="Nome do Aluno"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
            </input>
            <button type="submit">Cadastrar</button>
        </form>
    );
};

export default FormEstudante;