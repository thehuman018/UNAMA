import React, { useState } from "react";

const FormProfessor = ({ addProfessor }) => {
    const [name, setName] = useState('');
    const [subject, setSubject] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        addProfessor({name, subject});
        setName('');
        setSubject('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Cadastrar Professor</h2>
            <input>
                type="text"
                placeholder="Nome do Professor"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
            </input>
            <select value={subject} onChange={(e) => setSubject(e.target.value)} required>
                <option value="">Selecione a matéria</option>
                <option value="Sistemas Operacionais">Sistemas Operacionais</option>
                <option value="Front-End">Front-End</option>
                <option value="Back-End">Back-End</option>
                <option value="POO">Programação Orientada a Objetos</option>
            </select>
            <button type="submit">Cadastrar</button>
        </form>
    );
};

export default FormProfessor;